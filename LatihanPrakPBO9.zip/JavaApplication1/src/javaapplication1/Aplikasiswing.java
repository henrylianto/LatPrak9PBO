/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;
import javax.swing.*;
/**
 *
 * @author Henry Lianto
 */
public class Aplikasiswing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame f = new JFrame("title");
            JPanel p = new JPanel();
            JButton b = new JButton("press me");
            
            p.add(b);
            f.setContentPane(p);
            
            f.show();
    }

}
