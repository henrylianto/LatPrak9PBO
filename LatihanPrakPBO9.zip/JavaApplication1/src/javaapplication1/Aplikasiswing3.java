
 /*
 * @author Henry Lianto
 */
import javax.swing.*;
import java.awt.event.*;

public abstract class Aplikasiswing3 implements ActionListener {

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI() {
        JFrame frame = new JFrame("I am a JFrame"); frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20,30,400,200);
        frame.getContentPane().setLayout(null);
        
        JButton butt=new JButton("Click me");
        frame.getContentPane().add(butt);
        butt.setBounds(20,20,200,20);
        
        Aplikasiswing3 app = new Aplikasiswing3 () {};
        
        app.label = new JLabel("Nama saya..");
        app.label.setBounds(20,40, 200,20);
        frame.getContentPane().add(app.label);
        
        butt.addActionListener(app);
        frame.setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent e)
    {
        
        label.setText("Henry Lianto");
    }
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
                
            }
        });
    }
    
    JLabel label;
}
