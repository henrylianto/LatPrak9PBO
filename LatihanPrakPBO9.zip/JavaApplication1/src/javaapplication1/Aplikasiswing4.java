
/**
 *
 * @author Henry Lianto
 */
import javax.swing.*;
import java.awt.event.*;

public abstract class Aplikasiswing4 implements ActionListener{

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI(){
        JFrame frame = new JFrame("inkremen");
        //buat frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20,30,300,150);
        frame.getContentPane().setLayout(null);
        //Buat tombol
        JButton butt = new JButton("tambah");
        frame.getContentPane().add(butt);
        butt.setBounds(20,30,200,20);
        //membuat instance objek aplikasi
        Aplikasiswing4 app = new Aplikasiswing4() {};
        //make the label
        app.label = new JLabel("clicks=0");
        app.label.setBounds(20,50,200,20);
        frame.getContentPane().add(app.label);
        
        butt.addActionListener(app);
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        clickCount++;
        label.setText("clicks="+clickCount);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                createAndShowGUI();
            }
        });
    }
    int clickCount=0;
    JLabel label;   
}
